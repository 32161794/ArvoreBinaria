import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {
    private static ArvoreBinaria arvore = new ArvoreBinaria();

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        boolean encerrar = false;
        while (!encerrar) {
            System.out.println("Menu:");
            System.out.println("1- Carregar o texto");
            System.out.println("2- Contador de palavras");
            System.out.println("3- Busca por palavra");
            System.out.println("4- Exibição do texto");
            System.out.println("5- Encerrar");

            System.out.print("Digite a opção desejada: ");
            int opcao = teclado.nextInt();

            switch (opcao) {
                case 1:
                    try {
                        File arquivo = new File("LetraMusica.txt");
                        Scanner scanner = new Scanner(arquivo);

                        while (scanner.hasNext()) {
                            String palavra = scanner.next().replaceAll("[^a-zA-Z0-9]", "");
                            if (!palavra.isEmpty()) {
                                Palavra p = new Palavra(palavra.toLowerCase());
                                arvore.insere(p);
                            }
                        }

                        System.out.println("Texto carregado com sucesso!");

                    } catch (FileNotFoundException e) {
                        System.out.println("O arquivo LetraMusica.txt não foi encontrado.");
                    }

                    break;
                    
                    case 2:
                    System.out.print("Digite a palavra que deseja contar: ");
                    String palavra = teclado.next().toLowerCase();
                    Palavra p = arvore.busca(palavra);
                    if (p != null) {
                        System.out.println("A palavra \"" + p.getPalavra() + "\" aparece " + p.getOcorrencias() + " vezes.");
                    } else {
                        System.out.println("A palavra \"" + palavra + "\" não foi encontrada no texto.");
                    }
                    break;

                case 3:
                    System.out.print("Digite a palavra que deseja buscar: ");
                    palavra = teclado.next().toLowerCase();
                    p = arvore.busca(palavra);
                    if (p != null) {
                        System.out.println("A palavra \"" + p.getPalavra() + "\" aparece " + p.getOcorrencias() + " vezes no texto.");
                    } else {
                        System.out.println("A palavra \"" + palavra + "\" não foi encontrada no texto.");
                    }
                    break;

                  case 4:
                    System.out.println("Texto completo:");
                    arvore.exibe();
                    break;

                 case 5:
                    encerrar = true;
                    System.out.println("Encerrando o programa...");
                    break;

                default:
                    System.out.println("Opção inválida.");
                    break;
            }
        }

        teclado.close();
            }
        }