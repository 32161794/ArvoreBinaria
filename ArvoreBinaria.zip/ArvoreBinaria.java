public class ArvoreBinaria {
    private Node raiz;

    private class Node {
        private Palavra palavra;
        private Node esquerda;
        private Node direita;

        public Node(Palavra palavra) {
            this.palavra = palavra;
        }
    }

    public void insere(Palavra palavra) {
        raiz = insere(raiz, palavra);
    }

    private Node insere(Node node, Palavra palavra) {
        if (node == null) {
            return new Node(palavra);
        }

        int comparacao = palavra.getPalavra().compareTo(node.palavra.getPalavra());
        if (comparacao < 0) {
            node.esquerda = insere(node.esquerda, palavra);
        } else if (comparacao > 0) {
            node.direita = insere(node.direita, palavra);
        } else {
            node.palavra.incrementaOcorrencias();
        }

        return node;
    }

    public Palavra busca(String palavra) {
        Node node = busca(raiz, palavra);
        return node == null ? null : node.palavra;
    }

    private Node busca(Node node, String palavra) {
        if (node == null) {
            return null;
        }

        int comparacao = palavra.compareTo(node.palavra.getPalavra());
        if (comparacao < 0) {
            return busca(node.esquerda, palavra);
        } else if (comparacao > 0) {
            return busca(node.direita, palavra);
        } else {
            return node;
        }
    }

    private void exibe(Node node) {
        if (node == null) {
            return;
        }

        exibe(node.esquerda);
        System.out.println(node.palavra);
        exibe(node.direita);
    }

    public void exibe() {
        exibe(raiz);
    }
}